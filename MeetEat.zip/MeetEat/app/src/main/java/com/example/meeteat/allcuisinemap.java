package com.example.meeteat;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class allcuisinemap extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allcuisinemap);




        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }



    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng Bamboo = new LatLng(38.89997135955464, -77.04708280073022);
        mMap.addMarker(new MarkerOptions().position(Bamboo).title("Bamboo"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(Bamboo,16),5000,null);

        LatLng Bonmi = new LatLng(38.89984402733348, -77.04738589033741);
        mMap.addMarker(new MarkerOptions().position(Bonmi).title("Bonmi"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(Bonmi,16),5000,null);

        LatLng Penngrill = new LatLng(38.90114676899031, -77.043887512192);
        mMap.addMarker(new MarkerOptions().position(Penngrill).title("Penn Grill"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(Penngrill,16),5000,null);

        LatLng Charmthai = new LatLng(38.9037588052754, -77.05401018837975);
        mMap.addMarker(new MarkerOptions().position(Charmthai).title("Charm Thai"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(Charmthai,16),5000,null);

        LatLng Nooshi = new LatLng(38.904671266464014, -77.04373000365149);
        mMap.addMarker(new MarkerOptions().position(Nooshi).title("Noo Shi"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(Nooshi,16),5000,null);

        LatLng Chalin = new LatLng(38.901443765208505, -77.04409291721535);
        mMap.addMarker(new MarkerOptions().position(Chalin).title("Chalin's Restaurant"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(Chalin,16),5000,null);

        LatLng greenfield = new LatLng(38.90004929819551, -77.04692187023758);
        mMap.addMarker(new MarkerOptions().position(greenfield).title("Greenfield"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(greenfield,16),5000,null);

        LatLng metro = new LatLng(38.90002745114599, -77.04685224555266);
        mMap.addMarker(new MarkerOptions().position(metro).title("Metro"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(metro,16),5000,null);

        LatLng carving = new LatLng(38.89774962730745, -77.04517252146107);
        mMap.addMarker(new MarkerOptions().position(carving).title("Carvings"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(carving,16),5000,null);

        LatLng gw = new LatLng(38.89875572461319, -77.04824644420155);
        mMap.addMarker(new MarkerOptions().position(gw).title("GW Delicatessen"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(gw,16),5000,null);

        LatLng devon = new LatLng(38.902162009700305, -77.04796752153814);
        mMap.addMarker(new MarkerOptions().position(devon).title("Devon & Blakely"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(devon,16),5000,null);

        LatLng pot = new LatLng(38.89878812287486, -77.04899749086626);
        mMap.addMarker(new MarkerOptions().position(pot).title("Potbelly Sandwich Shop"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(pot,16),5000,null);

        LatLng and = new LatLng(38.897355178752534, -77.04892419872075);
        mMap.addMarker(new MarkerOptions().position(and).title("& Pizza"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(and,16),5000,null);

        LatLng subway = new LatLng(38.90317515950742, -77.04574400241953);
        mMap.addMarker(new MarkerOptions().position(subway).title("Subway"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(subway,16),5000,null);

        LatLng tonic = new LatLng(38.898814173114246, -77.04765635824143);
        mMap.addMarker(new MarkerOptions().position(tonic).title("Tonic at Quigley's"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(tonic,16),5000,null);

        LatLng circa = new LatLng(38.9012311144903, -77.0491378275563);
        mMap.addMarker(new MarkerOptions().position(circa).title("Circa at Foggy Bottom"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(circa,16),5000,null);

        LatLng bts = new LatLng(38.904983039810425, -77.04348418778243);
        mMap.addMarker(new MarkerOptions().position(bts).title("Burger Tap & Shake"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(bts,16),5000,null);

        LatLng founding = new LatLng(38.90363671978641, -77.04417085097174);
        mMap.addMarker(new MarkerOptions().position(founding).title("Founding Farmer"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(founding,16),5000,null);

        LatLng pesto = new LatLng(38.89983983335288, -77.0469889251601);
        mMap.addMarker(new MarkerOptions().position(pesto).title("Pesto"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(pesto,16),5000,null);

        LatLng bertuc = new LatLng(38.900568329997974, -77.0455277595441);
        mMap.addMarker(new MarkerOptions().position(bertuc).title("Bertucci's"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(bertuc,16),5000,null);

        LatLng star = new LatLng(38.89648188137944, -77.04403397358402);
        mMap.addMarker(new MarkerOptions().position(star).title("Starbuck"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(star,16),5000,null);

        LatLng juan = new LatLng(38.897756877618605, -77.04246509077613);
        mMap.addMarker(new MarkerOptions().position(juan).title("Juan Valdez Cafe"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(juan,16),5000,null);

        LatLng chipotle = new LatLng(38.90034289108367, -77.04532391166698);
        mMap.addMarker(new MarkerOptions().position(chipotle).title("Chipotle"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(chipotle,16),5000,null);

        LatLng nando = new LatLng(38.90819418330929, -77.03537873763966);
        mMap.addMarker(new MarkerOptions().position(nando).title("Nando's Peri Peri"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(nando,16),5000,null);

        LatLng beef = new LatLng(38.900687421431755, -77.04856867358396);
        mMap.addMarker(new MarkerOptions().position(beef).title("Beefsteak"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(beef,16),5000,null);

        LatLng perfect = new LatLng(38.90025104539489, -77.04632169338137);
        mMap.addMarker(new MarkerOptions().position(perfect).title("Perfect Pita"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(perfect,16),5000,null);

        LatLng poppa = new LatLng(38.9013473674857, -77.04414537358393);
        mMap.addMarker(new MarkerOptions().position(poppa).title("Poppa Box"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(poppa,16),5000,null);


        LatLng district = new LatLng(38.903491824889535, -77.0438558081643);
        mMap.addMarker(new MarkerOptions().position(district).title("District Common"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(district,16),5000,null);


    }

}