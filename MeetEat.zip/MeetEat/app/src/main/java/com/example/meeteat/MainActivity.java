package com.example.meeteat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button login;
    EditText user;
    EditText pass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        user = findViewById(R.id.username);
        pass = findViewById(R.id.password);
        login = findViewById(R.id.login);


        findViewById(R.id.createaccount).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),cust_information_Activity.class));
            }
        });


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username, password;
                username = user.getText().toString();
                password = pass.getText().toString();

                if (username.equals(""))
                {
                    Toast.makeText(MainActivity.this, "Username Required", Toast.LENGTH_SHORT).show();
                }
                else if (password.equals(""))
                {
                    Toast.makeText(MainActivity.this, "Password Required", Toast.LENGTH_SHORT).show();
                }
                else
                    {
                        Toast.makeText(MainActivity.this, "Welcome Back " + username, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, cust_preference_Activity.class);
                        intent.putExtra("username",username);
                        startActivity(intent);

                }



            }
        });

    }

    public void opencust_preference_Activity(){
        Intent intent = new Intent(this, cust_preference_Activity.class);
        startActivity(intent);
    }


}