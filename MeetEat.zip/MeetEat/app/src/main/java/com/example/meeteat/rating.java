package com.example.meeteat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

public class rating extends AppCompatActivity {
    private TextView message;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating);

        final RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingbar);
        Button submit = (Button) findViewById(R.id.ratebutton);
        message = findViewById(R.id.rateus);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (ratingBar.getRating() >= 4){
                    message.setText("We glad that you enjoy using our application");
                } else if (ratingBar.getRating() > 2 && ratingBar.getRating() <4){
                    message.setText("We hope to see you again");
                } else
                    message.setText("We are sorry to hear that");
            }
        });
    }
}