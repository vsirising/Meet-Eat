package com.example.meeteat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;


public class final_page_Activity extends AppCompatActivity {
private TextView username, gender, age, cuisine, date, time;
Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_page_);

        username = findViewById(R.id.username);
        gender = findViewById(R.id.genderinput);
        age = findViewById(R.id.ageinput);
        cuisine = findViewById(R.id.cuisineinput);
        date = findViewById(R.id.dateinput);
        time = findViewById(R.id.timeinput);
        button = findViewById(R.id.submitfinal);


        Intent receiveIntent = getIntent();
        String finalusername = receiveIntent.getStringExtra("username");
        String finalage1 = receiveIntent.getStringExtra("age1");
        String finalage2 = receiveIntent.getStringExtra("age2");
        String finaldate = receiveIntent.getStringExtra("date");
        String finaltime = receiveIntent.getStringExtra("time");
        String finalgender = receiveIntent.getStringExtra("radio");
        String finalcuisine = receiveIntent.getStringExtra("cuisine");


        username.setText(finalusername);
        gender.setText(finalgender);
        age.setText(finalage1 + " to " + finalage2);
        cuisine.setText(finalcuisine);
        date.setText(finaldate);
        time.setText(finaltime);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(final_page_Activity.this, "Submitted", Toast.LENGTH_SHORT).show();
                openratingActivity();
            }

        });

    }

    public void openratingActivity(){
        Intent intent = new Intent(this, rating.class);
        startActivity(intent);
    }
}