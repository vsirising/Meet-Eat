package com.example.meeteat;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class cust_preference_Activity extends AppCompatActivity {
    private Button next;
    private Button back;
    EditText age1;
    EditText age2;
    EditText date2;
    EditText time;
    TimePickerDialog timePickerDialog;
    RadioGroup radioGroup;
    RadioButton radioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cust_preference_);
        next = findViewById(R.id.nextbutton2);
        back = findViewById(R.id.backbutton2);
        age1 = findViewById(R.id.age1);
        age2 = findViewById(R.id.age2);
        date2 = findViewById(R.id.birthdate);
        time = findViewById(R.id.timenew);
        radioGroup = findViewById(R.id.radiogroup2);





        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        date2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        cust_preference_Activity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        month = month+1;
                        String date = day+"/"+month+"/"+year;
                        date2.setText(date);
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });

        time.setOnClickListener(new View.OnClickListener() {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR);
            int minute = calendar.get(Calendar.MINUTE);
            @Override
            public void onClick(View view) {
                timePickerDialog = new TimePickerDialog(cust_preference_Activity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int i, int i1) {
                        String AM_PM;
                        if(i<12){
                            AM_PM = "AM";
                            time.setText(i + ":"+i1+" "+ AM_PM);
                        }
                        else if (i == 12){
                            AM_PM = "PM";
                            time.setText(i + ":"+i1+" "+ AM_PM);
                        }
                        else {
                            AM_PM = "PM";
                            time.setText(i + ":"+i1+" "+ AM_PM);
                        }


                    }
                },hour, minute, false);
                timePickerDialog.show();

            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int radioId = radioGroup.getCheckedRadioButtonId();
                radioButton = findViewById(radioId);
                String firstage, secondage, date, timest, radio;


                firstage = age1.getText().toString();
                secondage = age2.getText().toString();
                date = date2.getText().toString();
                timest = time.getText().toString();
                radio = radioButton.getText().toString();


                if (firstage.equals(""))
                {
                    Toast.makeText(cust_preference_Activity.this, "Age range required", Toast.LENGTH_SHORT).show();
                }
                else if (secondage.equals(""))
                {
                    Toast.makeText(cust_preference_Activity.this, "Age range required", Toast.LENGTH_SHORT).show();
                }
                else if (date.equals(""))
                {
                    Toast.makeText(cust_preference_Activity.this, "Date required", Toast.LENGTH_SHORT).show();
                }
                else if (timest.equals(""))
                {
                    Toast.makeText(cust_preference_Activity.this, "Time required", Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent receiveIntent = getIntent();
                    String message1 = receiveIntent.getStringExtra("username");

                    Intent toCuisine = new Intent(cust_preference_Activity.this, cuisine_selection_Activity.class);
                    toCuisine.putExtra("username",message1);
                    toCuisine.putExtra("age1",firstage);
                    toCuisine.putExtra("age2",secondage);
                    toCuisine.putExtra("date",date);
                    toCuisine.putExtra("time",timest);
                    toCuisine.putExtra("radio",radio);


                    Toast.makeText(cust_preference_Activity.this, "Form submitted", Toast.LENGTH_SHORT).show();
                    startActivity(toCuisine);





                }
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMainActivity();
            }
        });
    }
    public void opencuisine_selection_Activity(){
        Intent intent = new Intent(this, cuisine_selection_Activity.class);
        startActivity(intent);
    }
    public void openMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void checkButton(View v){
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);
    }

}