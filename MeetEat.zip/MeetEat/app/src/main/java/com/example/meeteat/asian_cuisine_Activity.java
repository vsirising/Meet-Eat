package com.example.meeteat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class asian_cuisine_Activity extends AppCompatActivity {
    private Button back;
    private Button american;
    private Button italian;
    private Button cafe;
    private Button hispanic;
    private Button vegetarian;
    private Button medditeranean;
    private Button fusion;
    private Button bamboosubmit;
    private Button bonmisubmit;
    private Button penngrillsubmit;
    private Button charmthaisubmit;
    private Button nooshisubmit;
    private Button chalinsubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asian_cuisine_);
        back = findViewById(R.id.asianback);
        american = findViewById(R.id.american);
        italian = findViewById(R.id.italian);
        cafe = findViewById(R.id.cafe);
        hispanic = findViewById(R.id.hispanic);
        vegetarian = findViewById(R.id.vegetarian);
        medditeranean = findViewById(R.id.medditeranean);
        fusion = findViewById(R.id.fusion);
        bamboosubmit = findViewById(R.id.bamboochoose);
        bonmisubmit = findViewById(R.id.bonmichoose);
        penngrillsubmit = findViewById(R.id.penngrillchoose);
        charmthaisubmit = findViewById(R.id.charmthaichoose);
        nooshisubmit = findViewById(R.id.nooshichoose);
        chalinsubmit = findViewById(R.id.chalinchoose);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toAll = new Intent(asian_cuisine_Activity.this,cuisine_selection_Activity.class);
                toAll.putExtra("username",username);
                toAll.putExtra("age1",age1);
                toAll.putExtra("age2",age2);
                toAll.putExtra("date",date);
                toAll.putExtra("time",time);
                toAll.putExtra("radio",radio);
                Toast.makeText(asian_cuisine_Activity.this, "All Cuisine", Toast.LENGTH_SHORT).show();
                startActivity(toAll);
            }
        });

        american.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toAmerican = new Intent(asian_cuisine_Activity.this,american_cuisine_Activity.class);
                toAmerican.putExtra("username",username);
                toAmerican.putExtra("age1",age1);
                toAmerican.putExtra("age2",age2);
                toAmerican.putExtra("date",date);
                toAmerican.putExtra("time",time);
                toAmerican.putExtra("radio",radio);
                Toast.makeText(asian_cuisine_Activity.this, "American Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toAmerican);
            }
        });
        italian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toItalian = new Intent(asian_cuisine_Activity.this,italian_cusine_Activity.class);
                toItalian.putExtra("username",username);
                toItalian.putExtra("age1",age1);
                toItalian.putExtra("age2",age2);
                toItalian.putExtra("date",date);
                toItalian.putExtra("time",time);
                toItalian.putExtra("radio",radio);
                Toast.makeText(asian_cuisine_Activity.this, "Italian Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toItalian);
            }
        });
        cafe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toCafe = new Intent(asian_cuisine_Activity.this,cafe_cuisine_Activity.class);
                toCafe.putExtra("username",username);
                toCafe.putExtra("age1",age1);
                toCafe.putExtra("age2",age2);
                toCafe.putExtra("date",date);
                toCafe.putExtra("time",time);
                toCafe.putExtra("radio",radio);
                Toast.makeText(asian_cuisine_Activity.this, "Cafe Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toCafe);
            }
        });
        hispanic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toHispanic = new Intent(asian_cuisine_Activity.this,hispanic_cuisine_Activity.class);
                toHispanic.putExtra("username",username);
                toHispanic.putExtra("age1",age1);
                toHispanic.putExtra("age2",age2);
                toHispanic.putExtra("date",date);
                toHispanic.putExtra("time",time);
                toHispanic.putExtra("radio",radio);
                Toast.makeText(asian_cuisine_Activity.this, "Hispanic Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toHispanic);
            }
        });
        vegetarian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toVegetarian = new Intent(asian_cuisine_Activity.this,vegetarian_cuisine_Activity.class);
                toVegetarian.putExtra("username",username);
                toVegetarian.putExtra("age1",age1);
                toVegetarian.putExtra("age2",age2);
                toVegetarian.putExtra("date",date);
                toVegetarian.putExtra("time",time);
                toVegetarian.putExtra("radio",radio);
                Toast.makeText(asian_cuisine_Activity.this, "Vegetarian Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toVegetarian);
            }
        });
        medditeranean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toMedditeranean = new Intent(asian_cuisine_Activity.this,medditeranean_cuisine_Activity.class);
                toMedditeranean.putExtra("username",username);
                toMedditeranean.putExtra("age1",age1);
                toMedditeranean.putExtra("age2",age2);
                toMedditeranean.putExtra("date",date);
                toMedditeranean.putExtra("time",time);
                toMedditeranean.putExtra("radio",radio);
                Toast.makeText(asian_cuisine_Activity.this, "Medditeranean Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toMedditeranean);
            }
        });

        fusion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFusion = new Intent(asian_cuisine_Activity.this,fusion_cuisine_Activity.class);
                toFusion.putExtra("username",username);
                toFusion.putExtra("age1",age1);
                toFusion.putExtra("age2",age2);
                toFusion.putExtra("date",date);
                toFusion.putExtra("time",time);
                toFusion.putExtra("radio",radio);
                Toast.makeText(asian_cuisine_Activity.this, "Fusion Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFusion);
            }
        });
        bamboosubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(asian_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Bamboo");
                Toast.makeText(asian_cuisine_Activity.this, "Bamboo Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        bonmisubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(asian_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Bonmi");
                Toast.makeText(asian_cuisine_Activity.this, "Bonmi Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        penngrillsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(asian_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Penn Grill");
                Toast.makeText(asian_cuisine_Activity.this, "Penn Grill Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        charmthaisubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(asian_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Charm Thai");
                Toast.makeText(asian_cuisine_Activity.this, "Charm Thai Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        nooshisubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(asian_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Noo Shi");
                Toast.makeText(asian_cuisine_Activity.this, "Noo Shi Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        chalinsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(asian_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Chalin's Chinese Restaurant");
                Toast.makeText(asian_cuisine_Activity.this, "Chalin's Chinese Restaurant Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });

    }

}