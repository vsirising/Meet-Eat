package com.example.meeteat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class hispanic_cuisine_Activity extends AppCompatActivity {
    private Button back;
    private Button asian;
    private Button american;
    private Button italian;
    private Button cafe;
    private Button vegetarian;
    private Button medditeranean;
    private Button fusion;
    private Button chipotlesubmit;
    private Button nandosubmit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hispanic_cuisine_);
        back = findViewById(R.id.hispanicback);
        asian = findViewById(R.id.asian);
        american = findViewById(R.id.american);
        italian = findViewById(R.id.italian);
        cafe = findViewById(R.id.cafe);
        vegetarian = findViewById(R.id.vegetarian);
        medditeranean = findViewById(R.id.medditeranean);
        fusion = findViewById(R.id.fusion);
        chipotlesubmit = findViewById(R.id.chipotlechoose);
        nandosubmit = findViewById(R.id.nandochoose);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toAll = new Intent(hispanic_cuisine_Activity.this,cuisine_selection_Activity.class);
                toAll.putExtra("username",username);
                toAll.putExtra("age1",age1);
                toAll.putExtra("age2",age2);
                toAll.putExtra("date",date);
                toAll.putExtra("time",time);
                toAll.putExtra("radio",radio);
                Toast.makeText(hispanic_cuisine_Activity.this, "All Cuisines", Toast.LENGTH_SHORT).show();
                startActivity(toAll);
            }
        });

        asian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toAsian = new Intent(hispanic_cuisine_Activity.this,asian_cuisine_Activity.class);
                toAsian.putExtra("username",username);
                toAsian.putExtra("age1",age1);
                toAsian.putExtra("age2",age2);
                toAsian.putExtra("date",date);
                toAsian.putExtra("time",time);
                toAsian.putExtra("radio",radio);
                Toast.makeText(hispanic_cuisine_Activity.this, "Asian Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toAsian);
            }
        });
        american.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toAmerican = new Intent(hispanic_cuisine_Activity.this,american_cuisine_Activity.class);
                toAmerican.putExtra("username",username);
                toAmerican.putExtra("age1",age1);
                toAmerican.putExtra("age2",age2);
                toAmerican.putExtra("date",date);
                toAmerican.putExtra("time",time);
                toAmerican.putExtra("radio",radio);
                Toast.makeText(hispanic_cuisine_Activity.this, "American Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toAmerican);
            }
        });
        italian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toItalian = new Intent(hispanic_cuisine_Activity.this,italian_cusine_Activity.class);
                toItalian.putExtra("username",username);
                toItalian.putExtra("age1",age1);
                toItalian.putExtra("age2",age2);
                toItalian.putExtra("date",date);
                toItalian.putExtra("time",time);
                toItalian.putExtra("radio",radio);
                Toast.makeText(hispanic_cuisine_Activity.this, "Italian Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toItalian);
            }
        });
        cafe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toCafe = new Intent(hispanic_cuisine_Activity.this,cafe_cuisine_Activity.class);
                toCafe.putExtra("username",username);
                toCafe.putExtra("age1",age1);
                toCafe.putExtra("age2",age2);
                toCafe.putExtra("date",date);
                toCafe.putExtra("time",time);
                toCafe.putExtra("radio",radio);
                Toast.makeText(hispanic_cuisine_Activity.this, "Cafe Selected", Toast.LENGTH_SHORT).show();
                startActivity(toCafe);
            }
        });
        vegetarian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toVegetarian = new Intent(hispanic_cuisine_Activity.this,vegetarian_cuisine_Activity.class);
                toVegetarian.putExtra("username",username);
                toVegetarian.putExtra("age1",age1);
                toVegetarian.putExtra("age2",age2);
                toVegetarian.putExtra("date",date);
                toVegetarian.putExtra("time",time);
                toVegetarian.putExtra("radio",radio);
                Toast.makeText(hispanic_cuisine_Activity.this, "Vegetarian Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toVegetarian);
            }
        });
        medditeranean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toMedditeranean = new Intent(hispanic_cuisine_Activity.this,medditeranean_cuisine_Activity.class);
                toMedditeranean.putExtra("username",username);
                toMedditeranean.putExtra("age1",age1);
                toMedditeranean.putExtra("age2",age2);
                toMedditeranean.putExtra("date",date);
                toMedditeranean.putExtra("time",time);
                toMedditeranean.putExtra("radio",radio);
                Toast.makeText(hispanic_cuisine_Activity.this, "Medditeranean Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toMedditeranean);
            }
        });

        fusion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFusion = new Intent(hispanic_cuisine_Activity.this,fusion_cuisine_Activity.class);
                toFusion.putExtra("username",username);
                toFusion.putExtra("age1",age1);
                toFusion.putExtra("age2",age2);
                toFusion.putExtra("date",date);
                toFusion.putExtra("time",time);
                toFusion.putExtra("radio",radio);
                Toast.makeText(hispanic_cuisine_Activity.this, "Fusion Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFusion);
            }
        });
        chipotlesubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(hispanic_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Chipotle");
                Toast.makeText(hispanic_cuisine_Activity.this, "Chipotle Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        nandosubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(hispanic_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Nando's Peri Peri");
                Toast.makeText(hispanic_cuisine_Activity.this, "Nando's Peri-Peri Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });

    }

}