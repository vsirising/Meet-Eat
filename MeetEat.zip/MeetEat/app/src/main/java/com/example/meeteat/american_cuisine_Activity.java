package com.example.meeteat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class american_cuisine_Activity extends AppCompatActivity {
    private Button back;
    private Button asian;
    private Button italian;
    private Button cafe;
    private Button hispanic;
    private Button vegetarian;
    private Button medditeranean;
    private Button fusion;
    private Button greenfieldsubmit;
    private Button metrosubmit;
    private Button carvingsubmit;
    private Button gwsubmit;
    private Button devonsubmit;
    private Button potsubmit;
    private Button andsubmit;
    private Button subwaysubmit;
    private Button tonicsubmit;
    private Button circasubmit;
    private Button burgersubmit;
    private Button foundingsubmit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_american_cuisine_);
        back = findViewById(R.id.americanback);
        asian = findViewById(R.id.asian);
        italian = findViewById(R.id.italian);
        cafe = findViewById(R.id.cafe);
        hispanic = findViewById(R.id.hispanic);
        vegetarian = findViewById(R.id.vegetarian);
        medditeranean = findViewById(R.id.medditeranean);
        fusion = findViewById(R.id.fusion);
        greenfieldsubmit = findViewById(R.id.greenfieldchoose);
        metrosubmit = findViewById(R.id.metrochoose);
        carvingsubmit = findViewById(R.id.carvingchoose);
        gwsubmit = findViewById(R.id.gwchoose);
        devonsubmit = findViewById(R.id.devonchoose);
        potsubmit = findViewById(R.id.potchoose);
        andsubmit = findViewById(R.id.andchoose);
        subwaysubmit = findViewById(R.id.subchoose);
        tonicsubmit = findViewById(R.id.tonicchoose);
        circasubmit = findViewById(R.id.circachoose);
        burgersubmit = findViewById(R.id.btschoose);
        foundingsubmit = findViewById(R.id.foundingchoose);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toAll = new Intent(american_cuisine_Activity.this,cuisine_selection_Activity.class);
                toAll.putExtra("username",username);
                toAll.putExtra("age1",age1);
                toAll.putExtra("age2",age2);
                toAll.putExtra("date",date);
                toAll.putExtra("time",time);
                toAll.putExtra("radio",radio);
                Toast.makeText(american_cuisine_Activity.this, "All Cuisines", Toast.LENGTH_SHORT).show();
                startActivity(toAll);
            }
        });

        asian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toAsian = new Intent(american_cuisine_Activity.this,asian_cuisine_Activity.class);
                toAsian.putExtra("username",username);
                toAsian.putExtra("age1",age1);
                toAsian.putExtra("age2",age2);
                toAsian.putExtra("date",date);
                toAsian.putExtra("time",time);
                toAsian.putExtra("radio",radio);
                Toast.makeText(american_cuisine_Activity.this, "Asian Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toAsian);
            }
        });
        italian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toItalian = new Intent(american_cuisine_Activity.this,italian_cusine_Activity.class);
                toItalian.putExtra("username",username);
                toItalian.putExtra("age1",age1);
                toItalian.putExtra("age2",age2);
                toItalian.putExtra("date",date);
                toItalian.putExtra("time",time);
                toItalian.putExtra("radio",radio);
                Toast.makeText(american_cuisine_Activity.this, "Italian Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toItalian);
            }
        });
        cafe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toCafe = new Intent(american_cuisine_Activity.this,cafe_cuisine_Activity.class);
                toCafe.putExtra("username",username);
                toCafe.putExtra("age1",age1);
                toCafe.putExtra("age2",age2);
                toCafe.putExtra("date",date);
                toCafe.putExtra("time",time);
                toCafe.putExtra("radio",radio);
                Toast.makeText(american_cuisine_Activity.this, "Cafe Selected", Toast.LENGTH_SHORT).show();
                startActivity(toCafe);
            }
        });
        hispanic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toHispanic = new Intent(american_cuisine_Activity.this,hispanic_cuisine_Activity.class);
                toHispanic.putExtra("username",username);
                toHispanic.putExtra("age1",age1);
                toHispanic.putExtra("age2",age2);
                toHispanic.putExtra("date",date);
                toHispanic.putExtra("time",time);
                toHispanic.putExtra("radio",radio);
                Toast.makeText(american_cuisine_Activity.this, "Hispanic Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toHispanic);
            }
        });
        vegetarian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toVegetarian = new Intent(american_cuisine_Activity.this,vegetarian_cuisine_Activity.class);
                toVegetarian.putExtra("username",username);
                toVegetarian.putExtra("age1",age1);
                toVegetarian.putExtra("age2",age2);
                toVegetarian.putExtra("date",date);
                toVegetarian.putExtra("time",time);
                toVegetarian.putExtra("radio",radio);
                Toast.makeText(american_cuisine_Activity.this, "Vegetarian Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toVegetarian);
            }
        });
        medditeranean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toMedditeranean = new Intent(american_cuisine_Activity.this,medditeranean_cuisine_Activity.class);
                toMedditeranean.putExtra("username",username);
                toMedditeranean.putExtra("age1",age1);
                toMedditeranean.putExtra("age2",age2);
                toMedditeranean.putExtra("date",date);
                toMedditeranean.putExtra("time",time);
                toMedditeranean.putExtra("radio",radio);
                Toast.makeText(american_cuisine_Activity.this, "Medditeranean Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toMedditeranean);
            }
        });

        fusion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFusion = new Intent(american_cuisine_Activity.this,fusion_cuisine_Activity.class);
                toFusion.putExtra("username",username);
                toFusion.putExtra("age1",age1);
                toFusion.putExtra("age2",age2);
                toFusion.putExtra("date",date);
                toFusion.putExtra("time",time);
                toFusion.putExtra("radio",radio);
                Toast.makeText(american_cuisine_Activity.this, "Fusion Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFusion);
            }
        });
        greenfieldsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(american_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Greenfields");
                Toast.makeText(american_cuisine_Activity.this, "Grenfields Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        metrosubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(american_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Metro Diner");
                Toast.makeText(american_cuisine_Activity.this, "Metro Diner Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        carvingsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(american_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Carving's");
                Toast.makeText(american_cuisine_Activity.this, "Carving Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        gwsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(american_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","GW Delicatessen");
                Toast.makeText(american_cuisine_Activity.this, "GW Delicatessen Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        devonsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(american_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Devon & Blakely");
                Toast.makeText(american_cuisine_Activity.this, "Devon & Blakely Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        potsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(american_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Potbelly Sandwich Works");
                Toast.makeText(american_cuisine_Activity.this, "Potbelly Sandwich Works Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        andsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(american_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","& Pizza");
                Toast.makeText(american_cuisine_Activity.this, "& Pizza Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        subwaysubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(american_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Subway");
                Toast.makeText(american_cuisine_Activity.this, "Subway Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        tonicsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(american_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Tonic at Quigley's");
                Toast.makeText(american_cuisine_Activity.this, "Tonic at Quigley's Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        circasubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(american_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","CIRCA at Foggy Bottom");
                Toast.makeText(american_cuisine_Activity.this, "CIRCA at Foggy Bottom Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        burgersubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(american_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Burger Top & Shake");
                Toast.makeText(american_cuisine_Activity.this, "Burger Tap & Shake Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        foundingsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(american_cuisine_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Founding Farmer");
                Toast.makeText(american_cuisine_Activity.this, "Founding Farmer Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });

    }

}