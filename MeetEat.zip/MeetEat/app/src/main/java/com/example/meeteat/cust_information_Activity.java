package com.example.meeteat;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class cust_information_Activity extends AppCompatActivity {
    Button submit;
    TextView signin;
    EditText username;
    EditText password;
    EditText name;
    EditText email;
    EditText birthdate;
    DatePickerDialog.OnDateSetListener setListener;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cust_information_);

        username = findViewById(R.id.pickuser);
        password = findViewById(R.id.pickpassword);
        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        submit = findViewById(R.id.nextbutton1);
        signin = findViewById(R.id.alreadysignin);
        birthdate = findViewById(R.id.editbirthdate);

        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        birthdate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        cust_information_Activity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        month = month+1;
                        String date = day+"/"+month+"/"+year;
                        birthdate.setText(date);
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user, pass, fullname, enteremail, bd;

                user = username.getText().toString();
                pass = password.getText().toString();
                fullname = name.getText().toString();
                enteremail = email.getText().toString();
                bd = birthdate.getText().toString();


                if (user.equals(""))
                {
                    Toast.makeText(cust_information_Activity.this, "Username Required", Toast.LENGTH_SHORT).show();
                }
                else if (pass.equals(""))
                {
                    Toast.makeText(cust_information_Activity.this, "Password Required", Toast.LENGTH_SHORT).show();
                }
                else if (fullname.equals(""))
                {
                    Toast.makeText(cust_information_Activity.this, "Full name Required", Toast.LENGTH_SHORT).show();
                }
                else if (enteremail.equals(""))
                {
                    Toast.makeText(cust_information_Activity.this, "email Required", Toast.LENGTH_SHORT).show();
                }
                else if (bd.equals(""))
                {
                    Toast.makeText(cust_information_Activity.this, "Birthdate Required", Toast.LENGTH_SHORT).show();
                }
                else
                    { Toast.makeText(cust_information_Activity.this, "Account Created", Toast.LENGTH_SHORT).show();
                    openMainActivity();
                }
            }
        });

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMainActivity();
            }
        });
    }

    public void openMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}