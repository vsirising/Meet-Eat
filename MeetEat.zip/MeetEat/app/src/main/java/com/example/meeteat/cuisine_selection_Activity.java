package com.example.meeteat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class cuisine_selection_Activity extends AppCompatActivity {
    private Button asian;
    private Button american;
    private Button italian;
    private Button cafe;
    private Button hispanic;
    private Button vegetarian;
    private Button medditeranean;
    private Button fusion;
    private Button bamboosubmit;
    private Button bonmisubmit;
    private Button penngrillsubmit;
    private Button charmthaisubmit;
    private Button nooshisubmit;
    private Button chalinsubmit;
    private Button greenfieldsubmit;
    private Button metrosubmit;
    private Button carvingsubmit;
    private Button gwsubmit;
    private Button devonsubmit;
    private Button potsubmit;
    private Button andsubmit;
    private Button subwaysubmit;
    private Button tonicsubmit;
    private Button circasubmit;
    private Button burgersubmit;
    private Button foundingsubmit;
    private Button pestosubmit;
    private Button bertuccisubmit;
    private Button starbucksubmit;
    private Button juansubmit;
    private Button chipotlesubmit;
    private Button nandosubmit;
    private Button sweetgreensubmit;
    private Button beefsteaksubmit;
    private Button perfectsubmit;
    private Button poppasubmit;
    private Button districtsubmit;
    private Button map;







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cuisine_selection_);
        asian = findViewById(R.id.asian);
        american = findViewById(R.id.american);
        italian = findViewById(R.id.italian);
        cafe = findViewById(R.id.cafe);
        hispanic = findViewById(R.id.hispanic);
        vegetarian = findViewById(R.id.vegetarian);
        medditeranean = findViewById(R.id.medditeranean);
        fusion = findViewById(R.id.fusion);
        bamboosubmit = findViewById(R.id.bamboochoose);
        bonmisubmit = findViewById(R.id.bonmichoose);
        penngrillsubmit = findViewById(R.id.penngrillchoose);
        charmthaisubmit = findViewById(R.id.charmthaichoose);
        nooshisubmit = findViewById(R.id.nooshichoose);
        chalinsubmit = findViewById(R.id.chalinchoose);
        greenfieldsubmit = findViewById(R.id.greenfieldchoose);
        metrosubmit = findViewById(R.id.metrochoose);
        carvingsubmit = findViewById(R.id.carvingchoose);
        gwsubmit = findViewById(R.id.gwchoose);
        devonsubmit = findViewById(R.id.devonchoose);
        potsubmit = findViewById(R.id.potchoose);
        andsubmit = findViewById(R.id.andchoose);
        subwaysubmit = findViewById(R.id.subchoose);
        tonicsubmit = findViewById(R.id.tonicchoose);
        circasubmit = findViewById(R.id.circachoose);
        burgersubmit = findViewById(R.id.btschoose);
        foundingsubmit = findViewById(R.id.foundingchoose);
        pestosubmit = findViewById(R.id.pestochoose);
        bertuccisubmit = findViewById(R.id.bertucchoose);
        starbucksubmit = findViewById(R.id.starchoose);
        juansubmit = findViewById(R.id.juanchoose);
        chipotlesubmit = findViewById(R.id.chipotlechoose);
        nandosubmit = findViewById(R.id.nandochoose);
        sweetgreensubmit = findViewById(R.id.sweetgreenchoose);
        beefsteaksubmit = findViewById(R.id.beefsteakchoose);
        perfectsubmit = findViewById(R.id.perfectchoose);
        poppasubmit = findViewById(R.id.poppaboxchoose);
        districtsubmit = findViewById(R.id.districchoose);
        map = findViewById(R.id.mapbutton);


        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Openmap();
            }
        });




        asian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toAsian = new Intent(cuisine_selection_Activity.this,asian_cuisine_Activity.class);
                toAsian.putExtra("username",username);
                toAsian.putExtra("age1",age1);
                toAsian.putExtra("age2",age2);
                toAsian.putExtra("date",date);
                toAsian.putExtra("time",time);
                toAsian.putExtra("radio",radio);
                Toast.makeText(cuisine_selection_Activity.this, "Asian Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toAsian);
            }
        });
        american.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toAmerican = new Intent(cuisine_selection_Activity.this,american_cuisine_Activity.class);
                toAmerican.putExtra("username",username);
                toAmerican.putExtra("age1",age1);
                toAmerican.putExtra("age2",age2);
                toAmerican.putExtra("date",date);
                toAmerican.putExtra("time",time);
                toAmerican.putExtra("radio",radio);
                Toast.makeText(cuisine_selection_Activity.this, "American Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toAmerican);
            }
        });
        italian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toItalian = new Intent(cuisine_selection_Activity.this,italian_cusine_Activity.class);
                toItalian.putExtra("username",username);
                toItalian.putExtra("age1",age1);
                toItalian.putExtra("age2",age2);
                toItalian.putExtra("date",date);
                toItalian.putExtra("time",time);
                toItalian.putExtra("radio",radio);
                Toast.makeText(cuisine_selection_Activity.this, "Italian Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toItalian);
            }
        });
        cafe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toCafe = new Intent(cuisine_selection_Activity.this,cafe_cuisine_Activity.class);
                toCafe.putExtra("username",username);
                toCafe.putExtra("age1",age1);
                toCafe.putExtra("age2",age2);
                toCafe.putExtra("date",date);
                toCafe.putExtra("time",time);
                toCafe.putExtra("radio",radio);
                Toast.makeText(cuisine_selection_Activity.this, "Cafe Selected", Toast.LENGTH_SHORT).show();
                startActivity(toCafe);

            }
        });
        hispanic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toHispanic = new Intent(cuisine_selection_Activity.this,hispanic_cuisine_Activity.class);
                toHispanic.putExtra("username",username);
                toHispanic.putExtra("age1",age1);
                toHispanic.putExtra("age2",age2);
                toHispanic.putExtra("date",date);
                toHispanic.putExtra("time",time);
                toHispanic.putExtra("radio",radio);
                Toast.makeText(cuisine_selection_Activity.this, "Hispanic Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toHispanic);
            }
        });
        vegetarian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toVegetarian = new Intent(cuisine_selection_Activity.this,vegetarian_cuisine_Activity.class);
                toVegetarian.putExtra("username",username);
                toVegetarian.putExtra("age1",age1);
                toVegetarian.putExtra("age2",age2);
                toVegetarian.putExtra("date",date);
                toVegetarian.putExtra("time",time);
                toVegetarian.putExtra("radio",radio);
                Toast.makeText(cuisine_selection_Activity.this, "Vegetarian Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toVegetarian);
            }
        });
        medditeranean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toMedditeranean = new Intent(cuisine_selection_Activity.this,medditeranean_cuisine_Activity.class);
                toMedditeranean.putExtra("username",username);
                toMedditeranean.putExtra("age1",age1);
                toMedditeranean.putExtra("age2",age2);
                toMedditeranean.putExtra("date",date);
                toMedditeranean.putExtra("time",time);
                toMedditeranean.putExtra("radio",radio);
                Toast.makeText(cuisine_selection_Activity.this, "Medditeranean Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toMedditeranean);
            }
        });
        fusion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFusion = new Intent(cuisine_selection_Activity.this,fusion_cuisine_Activity.class);
                toFusion.putExtra("username",username);
                toFusion.putExtra("age1",age1);
                toFusion.putExtra("age2",age2);
                toFusion.putExtra("date",date);
                toFusion.putExtra("time",time);
                toFusion.putExtra("radio",radio);
                Toast.makeText(cuisine_selection_Activity.this, "Fusion Cuisines Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFusion);
            }
        });
        bamboosubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Bamboo");
                Toast.makeText(cuisine_selection_Activity.this, "Bamboo Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        bonmisubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Bonmi");
                Toast.makeText(cuisine_selection_Activity.this, "Bonmi Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);

            }
        });
        penngrillsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Penn Grill");
                Toast.makeText(cuisine_selection_Activity.this, "Penn Grill Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        charmthaisubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Charm Thai");
                Toast.makeText(cuisine_selection_Activity.this, "Charm Thai Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        nooshisubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Noo Shi");
                Toast.makeText(cuisine_selection_Activity.this, "Noo Shi Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        chalinsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Chalin's Chinese Restaurant");
                Toast.makeText(cuisine_selection_Activity.this, "Chalin's Chinese Restaurant Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        greenfieldsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Greenfields");
                Toast.makeText(cuisine_selection_Activity.this, "Greenfields Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        metrosubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Metro Diner");
                Toast.makeText(cuisine_selection_Activity.this, "Metro Diner Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        carvingsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Carving's");
                Toast.makeText(cuisine_selection_Activity.this, "Carving's Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        gwsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","GW Delicatessen");
                Toast.makeText(cuisine_selection_Activity.this, "GW Delicatessen Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        devonsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Devon & Blakely");
                Toast.makeText(cuisine_selection_Activity.this, "Devon & Blakely Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        potsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Potbelly Sandwich Works");
                Toast.makeText(cuisine_selection_Activity.this, "Potbelly Sandwich Works Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        andsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","& Pizza");
                Toast.makeText(cuisine_selection_Activity.this, "& Pizza Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        subwaysubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Subway");
                Toast.makeText(cuisine_selection_Activity.this, "Subway Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        tonicsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Tonic at Quigley's");
                Toast.makeText(cuisine_selection_Activity.this, "Tonic at Quigley's Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        circasubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","CIRCA at Foggy Bottom");
                Toast.makeText(cuisine_selection_Activity.this, "CIRCA at Foggy Bottom Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        burgersubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Burger Top & Shake");
                Toast.makeText(cuisine_selection_Activity.this, "Burger Tap & Shake Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        foundingsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Founding Farmer");
                Toast.makeText(cuisine_selection_Activity.this, "Founding Farmer Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        pestosubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Pesto");
                Toast.makeText(cuisine_selection_Activity.this, "Pesto Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        bertuccisubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Bertucci's");
                Toast.makeText(cuisine_selection_Activity.this, "Bertucci's Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        starbucksubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Starbuck");
                Toast.makeText(cuisine_selection_Activity.this, "Starbuck Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        juansubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Juan Valdez Cafe");
                Toast.makeText(cuisine_selection_Activity.this, "Juan Valdez Cafe Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        chipotlesubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Chipotle");
                Toast.makeText(cuisine_selection_Activity.this, "Chipotle Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        nandosubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Nando's Peri Peri");
                Toast.makeText(cuisine_selection_Activity.this, "Nando's Peri-Peri Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        sweetgreensubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Sweetgreen");
                Toast.makeText(cuisine_selection_Activity.this, "Sweetgreen Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        beefsteaksubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Beefsteak");
                Toast.makeText(cuisine_selection_Activity.this, "Beefsteak Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        perfectsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Perfect Pita");
                Toast.makeText(cuisine_selection_Activity.this, "Perfect Pita Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        poppasubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","Poppa Box");
                Toast.makeText(cuisine_selection_Activity.this, "Poppa Box Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });
        districtsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent receiveIntent = getIntent();
                String username = receiveIntent.getStringExtra("username");
                String age1 = receiveIntent.getStringExtra("age1");
                String age2 = receiveIntent.getStringExtra("age2");
                String date = receiveIntent.getStringExtra("date");
                String time = receiveIntent.getStringExtra("time");
                String radio = receiveIntent.getStringExtra("radio");

                Intent toFinal = new Intent(cuisine_selection_Activity.this,final_page_Activity.class);
                toFinal.putExtra("username",username);
                toFinal.putExtra("age1",age1);
                toFinal.putExtra("age2",age2);
                toFinal.putExtra("date",date);
                toFinal.putExtra("time",time);
                toFinal.putExtra("radio",radio);
                toFinal.putExtra("cuisine","District Commons");
                Toast.makeText(cuisine_selection_Activity.this, "District Commons Selected", Toast.LENGTH_SHORT).show();
                startActivity(toFinal);
            }
        });



    }
    public void Openmap(){
        Intent intent = new Intent(this, allcuisinemap.class);
        startActivity(intent);
    }
}